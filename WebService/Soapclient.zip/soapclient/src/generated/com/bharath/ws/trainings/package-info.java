@javax.xml.bind.annotation.XmlSchema(namespace = "http://trainings.ws.bharath.com/")
package com.bharath.ws.trainings;
